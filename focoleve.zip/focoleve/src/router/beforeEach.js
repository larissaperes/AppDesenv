
import * as storage from '../views/auth/storage'
import store from '../store'

export default async (to, from, next) => {

  document.title = `${to.meta.title} - Foco Leve`

  if (to.name !== 'login' && !storage.getIdSession()) {

    try {
      await store.dispatch('auth/ActionCheckUID')
      next({ name: to.name })
    } catch (err) {
      next({ name: 'login' })
    }
  } else {
    if (to.name === 'login' && storage.getIdSession()) {
      next({ name: 'home' })
    } else {
      next()
    }
  }
}
