<template>
  <v-app dark>
    <base-spinner></base-spinner>
    <v-app-bar app v-if="isLogged()">
      <v-toolbar-title class="headline text-uppercase">
        <span>FOCO LEVE</span>
        <span class="font-weight-light"> Disciplina na saúde </span>
      </v-toolbar-title>
      <v-spacer></v-spacer>
      <v-btn text href="https://github.com/vuetifyjs/vuetify/releases/latest" target="_blank">
        <v-icon>fa-sign-out-alt</v-icon>
      </v-btn>
    </v-app-bar>

    <v-navigation-drawer app permanent v-if="isLogged()">
      <v-list-item>
        <v-list-item-content>
          <v-list-item-title class="title">Application</v-list-item-title>
          <v-list-item-subtitle>subtext</v-list-item-subtitle>
        </v-list-item-content>
      </v-list-item>

      <v-divider></v-divider>

      <v-list dense nav>
        <v-list-item>
          <v-list-item-icon>
            <v-icon>fa-brain</v-icon>
          </v-list-item-icon>

          <v-list-item-content>
            <v-list-item-title>Foco</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <v-content>
      <router-view></router-view>
    </v-content>
  </v-app>
</template>

<script>
import BaseSpinner from "./components/global/BaseSpinner";
import { mapActions, mapGetters } from "vuex";

export default {
  name: "App",
  components: {
    BaseSpinner
  },
  data: () => ({
    //
  }),
  methods: {
    ...mapGetters("auth", ["isLogged"])
  },
  mounted() {
  },
  created() {
    this.$vuetify.theme.dark = true;
  }
};
</script>
