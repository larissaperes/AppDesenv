import * as storage from '../storage'
import * as types from './mutation-types'
import firebase from 'firebase'

export const ActionDoLogin = ({ dispatch }, payload) => {
  return firebase.auth().signInWithEmailAndPassword(payload.email, payload.password).then(res => {
    console.log("Deu certo : ", res)
    dispatch("ActionSetLogged", true)
  })
}

export const ActionAuthStateChange = ({ dispatch }) => {

  return new Promise(async (resolve, reject) => {
    firebase.auth().onAuthStateChanged(user => {
      if (user) {
        dispatch("ActionSetLogged", true)
        resolve()
      } else {
        dispatch('ActionSignOut')
        reject("Sessao encerrada")
      }
    })
  })
}
export const ActionCheckUID = ({ dispatch }) => {
  const uid = storage.hasIdSession()
  if (uid) {
    dispatch("ActionSetLogged", true)
    return Promise.resolve()
  }

  return dispatch('ActionAuthStateChange')
}

export const ActionSetLogged = ({ commit }, payload) => {
  commit(types.SET_LOGGED, payload)
}

export const ActionSignOut = () => {
  firebase.auth().signOut()
  storage.setIdSession("")
}