export const SET_USER = 'AUTH/SET_USER'
export const SET_LOGGED = 'AUTH/SET_LOGGED'