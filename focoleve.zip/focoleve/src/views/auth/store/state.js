export default {
    user: {},
    logged: undefined
  }
  