<template>
  <v-layout justify-center>
    <v-btn color="primary" dark @click="dialog = true">Cadastrar <v-icon>fa-user-plus</v-icon>
    </v-btn>
    <v-dialog v-model="dialog" persistent max-width="500px">
      <v-card>
        <v-card-title>
          <span class="headline">Cadastrar usuário</span>
        </v-card-title>
        <v-card-text>
          <v-container grid-list-md>
            <v-layout wrap>
              <v-flex xs12>
                <v-text-field label="Email*" required></v-text-field>
              </v-flex>
              <v-flex xs12>
                <v-text-field label="Password*" type="password" required></v-text-field>
              </v-flex>
            </v-layout>
          </v-container>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="blue darken-1" text @click="dialog = false">Close</v-btn>
          <v-btn color="blue darken-1" text @click="dialog = false">Save</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
  </v-layout>
</template>

<script>
import { mapActions } from "vuex";

export default {
  name: "Signup",
  data: () => ({
    email: "",
    password: "",
    dialog: false
  }),
  methods: {
    ...mapActions("auth", ["ActionDoLogin"]),
    async doLogin() {
      try {
        await this.ActionDoLogin({
          email: this.email,
          password: this.password
        });
      } catch (error) {
        console.log("Erro ao logar: ", error);
      } finally {
      }
    }
  }
};
</script>