<template>
  <v-app dark>
    <v-content>
      <form @submit.prevent="doLogin">
        <v-container fluid fill-height>
          <v-layout align-center justify-center>
            <v-flex xs12 sm8 md4>
              <v-card class="elevation-12">
                <v-toolbar color="orange darken-4" dark flat>
                  <v-toolbar-title>FOCO LEVE</v-toolbar-title>
                  <v-spacer></v-spacer>
                  <signup />
                </v-toolbar>
                <v-card-text>
                  <v-form>
                    <v-text-field
                      label="E-mail"
                      v-model="email"
                      prepend-icon="fa-user"
                      type="email"
                    ></v-text-field>

                    <v-text-field
                      label="Password"
                      v-model="password"
                      prepend-icon="fa-lock"
                      type="password"
                    ></v-text-field>
                  </v-form>
                </v-card-text>
                <v-card-actions pa-5>
                  <v-spacer></v-spacer>
                  <v-btn type="submit" color="orange darken-4 pr-5 pl-5" >
                    <template v-if="loading">
                      Logando...
                      <v-progress-circular indeterminate color="amber"></v-progress-circular>
                    </template>
                    <template v-else>
                      Logar
                      <v-icon>fa-sign-in-alt</v-icon>
                    </template>
                  </v-btn>
                </v-card-actions>
              </v-card>
            </v-flex>
          </v-layout>
        </v-container>
      </form>
    </v-content>
  </v-app>
</template>

<script>
import Signup from "./Signup";
import { mapActions } from "vuex";

export default {
  name: "Login",
  data: () => ({
    email: "",
    password: "",
    loading: false
  }),
  methods: {
    ...mapActions("auth", ["ActionDoLogin"]),
    async doLogin() {
      this.loading = true;
      try {
        await this.ActionDoLogin({
          email: this.email,
          password: this.password
        });

        this.$router.push({ name: "home" });
      } catch (error) {
        console.log("Erro ao logar: ", error);
      }

      this.loading = false;
    }
  },
  components: {
    Signup
  }
};
</script>