<template>
  <div>Home</div>
</template>

<script>
export default {};
</script>
