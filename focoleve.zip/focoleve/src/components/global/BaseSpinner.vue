<template>
  <div class="spinner" v-if="visible">
    <v-layout align-content-center justify-center fill-height
        wrap>
      <v-flex xs12 subtitle-1 text-center white--text>aguarde...</v-flex>
      <v-flex xs6>
        <v-progress-linear color="cyan accent-3" indeterminate rounded height="6"></v-progress-linear>
      </v-flex>
    </v-layout>
  </div>
</template>

<script>
export default {
  data() {
    return {
      visible: false
    };
  },
  created() {
    this.$root.$on("Spinner::show", () => {
      this.visible = true;
    });
    this.$root.$on("Spinner::hide", () => {
      this.visible = false;
    });
  }
};
</script>

<style scoped>
.spinner {
  top: 0 !important;
  bottom: 0 !important;
  right: 0 !important;
  left: 0 !important;
  z-index: 50000;
  position: absolute;
  width: 100vw !important;
  height: 100vh !important;
  display: flex;
  align-items: center;
  justify-content: center;
  background-color: #32325db8;
}
</style>
