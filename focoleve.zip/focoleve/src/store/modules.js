import { store as auth } from '@/views/auth'

export default {
    auth
}